package hbinh.com.quanlysach;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainInputBillActivity extends AppCompatActivity {

    Button btncreatebill;
    EditText edtbillnumber,edtdatebill;
    public static String strCodebill,strDatebill;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_input_bill);

        btncreatebill = findViewById(R.id.btncreatebill);



        btncreatebill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                strCodebill = edtbillnumber.getText().toString();
                strDatebill = edtdatebill.getText().toString();
                Intent intent = new Intent(MainInputBillActivity.this,MainBuyBookActivity.class);
                startActivity(intent);
            }
        });
    }
}
