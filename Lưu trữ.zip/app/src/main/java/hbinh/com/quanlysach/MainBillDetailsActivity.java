package hbinh.com.quanlysach;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import hbinh.com.quanlysach.Adapter.BillDetailsAdapter;
import hbinh.com.quanlysach.Model.BillDetails;

public class MainBillDetailsActivity extends AppCompatActivity {

    ListView lvbilldetails;
    ArrayList<BillDetails> dsDetails = new ArrayList<>();
    BillDetailsAdapter detailsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bill_details);

        lvbilldetails = findViewById(R.id.lvbilldetails);

        BillDetails billDetails = new BillDetails("JAVA 1",5,100,500);
        BillDetails billDetails1 = new BillDetails("CNTT 1",5,100,500);
        dsDetails.add(billDetails);
        dsDetails.add(billDetails1);

        detailsAdapter = new BillDetailsAdapter(this,dsDetails);
        lvbilldetails.setAdapter(detailsAdapter);
    }
}
