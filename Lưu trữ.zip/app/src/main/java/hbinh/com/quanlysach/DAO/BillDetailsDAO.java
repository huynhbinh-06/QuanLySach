package hbinh.com.quanlysach.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import hbinh.com.quanlysach.Database.DatabaseHelper;
import hbinh.com.quanlysach.Model.BillDetails;

public class BillDetailsDAO {

    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME="billdetails";
    public static final String SQL_BILLDETAILS = "CREATE TABLE billdetails "+"("+"masach text PRIMARY KEY,"+" soluongsach integer," +
            "giabiasach double," +
            "giatong double"+")";

    public BillDetailsDAO(Context context){
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public int insertBillDetails(BillDetails billDetails){
        ContentValues values = new ContentValues();
        values.put("masach",billDetails.getMasach());
        values.put("soluongsach",billDetails.getSoluongsach());
        values.put("giabiasach",billDetails.getGiabiasach());
        values.put("giatong",billDetails.getGiatong());

        try {
            if (db.insert(TABLE_NAME,null,values)==-1)
                return 1;
        }
        catch (Exception e){

        }
        return -1;
    }
    public ArrayList<BillDetails> getAllBillDetails(){
        ArrayList<BillDetails> dsBillDetails = new ArrayList<>();
        Cursor cursor = db.query(TABLE_NAME,null,null,null,null,null,null,null);
        cursor.moveToFirst();

        while (cursor.isAfterLast()==false){
            BillDetails billDetails = new BillDetails();
            billDetails.setMasach(cursor.getString(0));
            billDetails.setSoluongsach(cursor.getInt(1));
            billDetails.setGiabiasach(cursor.getDouble(2));
            billDetails.setGiatong(cursor.getDouble(3));

            dsBillDetails.add(billDetails);
            cursor.moveToNext();
        }
        cursor.close();
        return dsBillDetails;
    }

}
