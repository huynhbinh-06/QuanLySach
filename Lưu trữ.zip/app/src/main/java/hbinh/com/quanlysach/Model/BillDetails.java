package hbinh.com.quanlysach.Model;

public class BillDetails {

    String masach;
    int soluongsach;
    double giabiasach;
    double giatong;

    public BillDetails(String masach, int soluongsach, double giabiasach, double giatong) {
        this.masach = masach;
        this.soluongsach = soluongsach;
        this.giabiasach = giabiasach;
        this.giatong = giatong;
    }

    public BillDetails() {
    }

    public String getMasach() {
        return masach;
    }

    public void setMasach(String masach) {
        this.masach = masach;
    }

    public int getSoluongsach() {
        return soluongsach;
    }

    public void setSoluongsach(int soluongsach) {
        this.soluongsach = soluongsach;
    }

    public double getGiabiasach() {
        return giabiasach;
    }

    public void setGiabiasach(double giabiasach) {
        this.giabiasach = giabiasach;
    }

    public double getGiatong() {
        return giatong;
    }

    public void setGiatong(double giatong) {
        this.giatong = giatong;
    }
}
