package hbinh.com.quanlysach;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;

import hbinh.com.quanlysach.Adapter.BillAdapter;
import hbinh.com.quanlysach.Model.ListBill;

public class MainListBillActivity extends AppCompatActivity {

    ImageView imgfindbill;
    ListView listviewbill;
    ArrayList<ListBill> dsBill = new ArrayList<>();
    BillAdapter billAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_list_bill);

        imgfindbill = findViewById(R.id.imgfindbill);
        listviewbill = findViewById(R.id.listviewbill);

        ListBill listBill = new ListBill("01","11/09/2019");
        ListBill listBill1 = new ListBill("02","12/09/2019");
        dsBill.add(listBill);
        dsBill.add(listBill1);

        billAdapter = new BillAdapter(this,dsBill);
        listviewbill.setAdapter(billAdapter);

        imgfindbill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainListBillActivity.this,MainBillDetailsActivity.class);
                startActivity(intent);
            }
        });
    }
}
